class Config(object):
    DEFAULT_TEMPERATURE = 20
    LOWEST = 0 
    HIGHEST = 100
    PASSWORD = '8xk2--cfhs3'
